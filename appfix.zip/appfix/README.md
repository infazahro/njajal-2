## Title
App Quran with Django
## Description
play quran perayat dengan cara memilih surat, ayat dan jumlah ulang putar audio quran
## Author
infa zahro
## Running

```
python manage.py runserver
```
