from django.contrib import admin
from .models import Qori, Murotal

admin.site.register(Qori)
admin.site.register(Murotal)


