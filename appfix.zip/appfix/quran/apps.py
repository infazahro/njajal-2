from django.apps import AppConfig

class QuranConfig(AppConfig):
    name = 'quran'
